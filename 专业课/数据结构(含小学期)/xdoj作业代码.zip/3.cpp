#include <iostream>
#include <vector>
#include <string>
using namespace std;
struct TreeNode {
	char value;
	TreeNode *left;
	TreeNode *right;
	TreeNode(char val) : value(val), left(nullptr), right(nullptr) {}
};
void insertNode(TreeNode *root, const string &code) {
	TreeNode *current = root;
	for (char direction : code) {
		if (direction == '0') {
			if (!current->left) {
				current->left = new TreeNode('0');
			}
			current = current->left;
		} else if (direction == '1') {
			if (!current->right) {
				current->right = new TreeNode('1');
			}
			current = current->right;
		}
	}
}
void inorderTraversal(TreeNode *root) {
	if (root == nullptr) {
		return;
	}
	cout << '[';
	inorderTraversal(root->left);
	cout << root->value << " ";
	inorderTraversal(root->right);
	cout << ']';
}
int main() {
	int n;
	cin >> n;
	vector<string> codes(n);
	for (int i = 0; i < n; i++) {
		cin >> codes[i];
	}
	TreeNode *root = new TreeNode('r');
	for (const string &code : codes) {
		insertNode(root, code);
	}
	inorderTraversal(root);
	return 0;
}