#include"stdio.h"

void main(){
	int i=1;
	while(i){
		printf("%d\n",i++); 
	}
} 
