#include "stdio.h"
#include "malloc.h"
#include "string.h"
#define FactSize 50                    
#define STATUS int
#define TRUE 1                      
#define FALSE 0                    

typedef char FACT[FactSize];              
struct FACTNODE
{
    FACT fact;                    
    struct  FACTNODE *next;          
};

typedef struct FACTNODE *FACTS;

typedef struct {
    FACTS ifs;        
    FACTS thens;      
} RULE;

struct RULENODE{         
    RULE rule;           
    struct RULENODE *next;     
};

typedef struct RULENODE *RULES;  

FACTS AddAFact(FACTS facts,FACT newfact)           
{
    struct FACTNODE *factnode,*lastnode;  
    factnode = (struct FACTNODE*) malloc(sizeof (struct FACTNODE)); 
    strcpy(factnode->fact,newfact);        
    factnode->next = NULL;
    if(facts == NULL) facts = factnode;                          
    else{
        lastnode = facts;              
        while (lastnode->next!=NULL) lastnode = lastnode->next;        
        lastnode->next = factnode;                 
    }
    return facts;
}

void priFacts(FACTS facts){
    while(facts!=NULL){
        printf("%s",facts->fact);
        facts = facts->next;             
        if(facts!=NULL) printf(",");        
    }
    printf("\n");
}

void CreateStr(char *factset){
    char *c = factset;          
    while (*c) {
        if (*c == '/') *c = '\0';    
        c++;
    }
    c++;
    *c = '\0';                    
}

FACTS CreateFacts(FACTS facts,char *factset){
    char *p = factset;
    FACT fact;
    CreateStr(factset);                
    while (*p){
        strcpy(fact,p);            
        facts = AddAFact(facts,fact);   
        p+=strlen(fact)+1;              
    }
    return facts;
}

FACTS CreateFactBase(FACTS facts,char *filename){
    FILE *fp;
    char factset[500];
    fp = fopen(filename,"r");               
    fscanf(fp,"%s",factset);               
    facts = CreateFacts(facts,factset);           
    fclose(fp);                              
    return facts;                            
}

FACTS ClearFactBase(FACTS facts){
    struct FACTNODE *fact = facts,*p;                   
    while (fact){
        p = fact;                        
        fact = fact->next;                   
        free(p);                                  
    }
    return NULL;                            
}

RULE* InitRule(){
    RULE *rule;                 
    rule = (RULE *) malloc(sizeof (RULE));  
    rule->ifs = NULL;                  
    rule->thens = NULL;
    return rule;
}

void AddAIf(RULE *rule,FACT newfact){
    rule->ifs = AddAFact(rule->ifs,newfact);     
}

void AddAThen(RULE *rule, FACT newfact){
    rule->thens = AddAFact(rule->thens,newfact);    
}

void AddIfs(RULE *rule,char *factset){
    char *p = factset;
    FACT fact;                         
    CreateStr(factset);                    
    while (*p){
        strcpy(fact, p);         
        AddAIf(rule ,fact);      
        p+= strlen(fact)+1;               
    }
}

void AddThens(RULE *rule,char *factset){
    char *p = factset;
    FACT fact;                         
    CreateStr(factset);                    
    while (*p){
        strcpy(fact, p);         
        AddAThen(rule ,fact);      
        p+= strlen(fact)+1;              
    }
}

RULE *CreateRule(char *ifset,char *thenset){
    RULE *rule;                         
    rule = InitRule();             
    AddIfs(rule ,ifset);                    
    AddThens(rule,thenset);                   
    return rule;
}

RULES AddARule(RULES rules, RULE rule){
    struct RULENODE *rulenode,*lastnode;
    rulenode = (struct RULENODE*) malloc(sizeof (struct RULENODE));            
    rulenode->rule = rule;              
    rulenode->next = NULL;
    if(rules == NULL)                    
        rules = rulenode;
    else{
        lastnode = rules;         
        while (lastnode->next!=NULL)  lastnode = lastnode->next;          
        lastnode->next = rulenode;
    }
    return rules;                   
}

RULES CreateRuleBase(RULES rules,char *filename){
    RULE *rule;
    FILE *fp;
    char ifset[5000],thenset[500];         
    fp = fopen(filename,"r");
    while (!feof(fp)){
        fscanf(fp,"%s",ifset);                            
        fscanf(fp,"%s",thenset);                           
        rule = CreateRule(ifset+4,thenset+4);               
        rules = AddARule(rules,*rule);               
    }
    fclose(fp);
    return rules;
}

void priRule(RULE *rule){
    FACTS ifs,thens;
    ifs = rule->ifs;
    thens = rule->thens;
    printf("IF ");          
    priFacts(ifs);
    printf("THEN ");
    priFacts(thens);                
}

RULES ClearRuleBase(RULES rules){
    struct RULENODE *rule = rules,*p;
    while (rule){
        p = rule;                 
        ClearFactBase(p->rule.ifs);
        ClearFactBase(p->rule.thens);
        rule = rule->next;                 
        free(p);                          
    }
    return NULL;
}

STATUS member(FACT fact,FACTS facts){
    STATUS flag = FALSE;                 
    struct FACTNODE *p = facts;        
    while (p){
        if(strcmp(p->fact,fact) == 0){
            flag = TRUE;
            break;
        }
        else{
            p = p->next;    
        }
	}                     
    return flag;                             
}

STATUS Match(FACTS subfacts, FACTS facts){
    STATUS flag = TRUE;                       
    struct FACTNODE *p = subfacts;              
    while (p){
        if(!member(p->fact,facts)){
            flag = FALSE;                
            break;
        }
        else{
            p = p->next;   
		}
	}                
    return flag;
}

FACTS update(FACTS subfacts, FACTS facts, STATUS *flag){
    struct FACTNODE *p = subfacts;                   
    *flag = FALSE;                         
    while (p)
        if(!member(p->fact,facts)){
            *flag = TRUE;                           
            facts = AddAFact(facts,p->fact);         
        }
        else
            p = p->next;                           
    return facts;
}

STATUS testIfs(FACTS ifs, FACTS facts){
    return Match(ifs,facts);
}

FACTS testThens(FACTS thens, FACTS facts,STATUS *flag){
    facts = update(thens, facts, flag);                
    return facts;
}

FACTS testRule(RULE *rule,FACTS facts,STATUS *flag){
    *flag = FALSE;
    if(testIfs(rule->ifs,facts))                        
        facts = testThens(rule->thens, facts, flag);   
    return facts;
}

FACTS stepforward(RULES rules, FACTS facts, STATUS *flag){
    do {
        facts = testRule(&(rules->rule), facts, flag);        
        if(*flag == TRUE){
            priRule(&(rules->rule));                        
            printf("===========================\n");
            break;
        }
        rules = rules->next;                             
    } while (rules);
    return facts;                                    
}

FACTS deducegui(RULES rules, FACTS facts, STATUS *flag){
    static STATUS success = FALSE;              
    facts = stepforward(rules, facts, flag);     
    if(*flag == TRUE){
        success = TRUE;                      
        facts = deducegui(rules, facts, flag);
    }
    *flag = success;
    return facts;
}

struct FACTNODE* deduceResult(FACTS facts){
    while (facts->next) facts = facts->next;         
    return facts;                       
}

void displayResult(struct  FACTNODE* result,STATUS flag){
    if(flag == TRUE) printf("DeduceResult=%s\n",result->fact);      
    else printf("DeduceResult=NO Result\n");
    printf("=================================\n");
}

void ProductionSYS(char *rulefilename,char *factfilename){ 
    RULES rules = NULL;
    FACTS facts = NULL;            
	struct FACTNODE *result = NULL;
    STATUS flag;                   
    facts = CreateFactBase(facts, factfilename);   
    printf("=======================================\nFact Base:\n");
    priFacts(facts);
    printf("=======================================\nDeducing Procedure:\n");
    rules = CreateRuleBase(rules, rulefilename);   
    facts = deducegui(rules, facts, &flag);         
    result = deduceResult(facts);                   
    displayResult(result, flag);                    
    ClearFactBase(facts);                           
    ClearRuleBase(rules);                            
}

int main(){
    char *factfilename = "C:\\Users\\19243\\Desktop\\��һ��ѧ�ڼ�ϰ\\����ר��ʶ��ϵͳ\\����ʶ��.txt";
    char *rulefilename = "C:\\Users\\19243\\Desktop\\��һ��ѧ�ڼ�ϰ\\����ר��ʶ��ϵͳ\\����.txt";
    ProductionSYS(rulefilename, factfilename);
}
