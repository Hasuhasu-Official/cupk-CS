#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct STNode {
    int data;
    struct STNode* next;
} STNode, *StackLink;

void push(StackLink* stack, int value);
int pop(StackLink* stack);
int compute(int operand1, int operand2, char operation);

int main() {
    char inputExpression[100];
    int index;
    StackLink stackOperands = NULL, stackResult = NULL;
    int operand1, operand2;
    char operation;
    scanf("%s", inputExpression);
    for (index = strlen(inputExpression) - 1; index >= 0; index--) {
        if (inputExpression[index] >= '0' && inputExpression[index] <= '9') {
            push(&stackOperands, inputExpression[index] - '0');
        } else {
            push(&stackOperands, (int)inputExpression[index]);
        }
    }
    while (stackOperands != NULL) {
        if (stackOperands->data >= 0 && stackOperands->data <= 9) {
            push(&stackResult, pop(&stackOperands));
        } else {
            operand2 = pop(&stackResult);
            operand1 = pop(&stackResult);
            operation = (char)pop(&stackOperands);
            push(&stackResult, compute(operand1, operand2, operation));
        }
    }
    printf("%d", stackResult->data);
    return 0;
}

void push(StackLink* stack, int value) {
    StackLink newNode = (StackLink)malloc(sizeof(STNode));
    newNode->data = value;
    newNode->next = *stack;
    *stack = newNode;
}

int pop(StackLink* stack) {
    StackLink tempNode = *stack;
    int value = tempNode->data;
    *stack = (*stack)->next;
    free(tempNode);
    return value;
}

int compute(int operand1, int operand2, char operation) {
    int result;
    switch (operation) {
        case '+':
            result = operand1 + operand2;
            break;
        case '-':
            result = operand1 - operand2;
            break;
        case '*':
            result = operand1 * operand2;
            break;
        case '/':
            result = operand1 / operand2;
            break;
    }
    return result;
}
