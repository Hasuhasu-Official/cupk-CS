#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
typedef struct StackNode
{
    int value;
    int type;
    struct StackNode* next;
} StackNode, * Stack;

void StackPush(Stack* stack, int element);
int StackPop(Stack* stack);

int main()
{
    char input[100];
    int index, digit;
    Stack stack = NULL;
    Stack output = NULL;
    int number = 0;
    scanf("%[^\n]", input);
    for (index = 0; input[index] != '\0';)
    {
        if (input[index] == '+' || input[index] == '-' || input[index] == '*' || input[index] == '/')
        {
            StackPush(&stack, input[index]);
            stack->type = 1;
            index++;
        }
        else if (input[index] >= '0' && input[index] <= '9')
        {
            do
            {
                number = number * 10 + (input[index] - '0');
                index++;
            } while (input[index] != ' ' && input[index] != '\0');
            StackPush(&stack, number);
            stack->type = 0;
            number = 0;
        }
        else
        {
            index++;
        }
    }
    while (stack != NULL)
    {
        if (stack->value == '+' && stack->type == 1)
        {
            StackPush(&output, StackPop(&output) + StackPop(&output));
            StackPop(&stack);
        }
        else if (stack->value == '-' && stack->type == 1)
        {
            StackPush(&output, StackPop(&output) - StackPop(&output));
            StackPop(&stack);
        }
        else if (stack->value == '*' && stack->type == 1)
        {
            StackPush(&output, StackPop(&output) * StackPop(&output));
            StackPop(&stack);
        }
        else if (stack->value == '/' && stack->type == 1)
        {
            StackPush(&output, StackPop(&output) / StackPop(&output));
            StackPop(&stack);
        }
        else
        {
            StackPush(&output, StackPop(&stack));
        }
    }
    printf("%d", output->value);
    return 0;
}

void StackPush(Stack* stack, int element)
{
    Stack node = (Stack)malloc(sizeof(StackNode));
    node->next = *stack;
    node->value = element;
    *stack = node;
}

int StackPop(Stack* stack)
{
    Stack node = *stack;
    int element = node->value;
    *stack = (*stack)->next;
    free(node);
    return element;
}
