#include <iostream>
#include <set>
#include <string>
using namespace std;

// �������ű�ʾ���ַ���ת��Ϊ�ַ������ϵĺ���
set<string> extractStringSet(const string& strRep) {
    set<string> elementsSet;
    string currentElement;
    for (char ch : strRep) {
        if (ch == ',' || ch == '}') {
            if (!currentElement.empty()) {
                elementsSet.insert(currentElement);
                currentElement.clear();
            }
        } else if (ch != '{') {
            currentElement += ch;
        }
    }
    if (!currentElement.empty()) {
        elementsSet.insert(currentElement);
    }
    return elementsSet;
}

int main() {
    string inputStrA, inputStrB;
    cin >> inputStrA >> inputStrB;
    set<string> setA = extractStringSet(inputStrA);
    set<string> setB = extractStringSet(inputStrB);
    if (setA == setB) {
        cout << "Yes" << endl;
    } else {
        cout << "No" << endl;
    }
    return 0;
}
