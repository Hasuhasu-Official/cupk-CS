#include"stdio.h"
#include"stdlib.h"

#define LEN 3
#define MAX 363000 

typedef struct{
	int grid[LEN][LEN];
}*SDL,SDN;

SDL Queue[MAX];
int rear = -1,front = -1;

SDL getNewSudoku(SDL SD,int row0,int col0,int row,int col);
void changeAddress(SDL SD);
SDL copySdoku(SDL becopied);
void enqueue(SDL SD);
void findBechanged(SDL SD,int* row,int* col);
void outputSudoku(SDL SD);
SDL NewSDL();

void main(){
	SDL start = NewSDL();
	enqueue(start);
	changeAddress(start);
}

SDL NewSDL(){
	SDL SD = (SDL)malloc(sizeof(SDN));
	if(SD != NULL){
		int row,col;
		printf("\n\n��Ϊ���ľŹ���ֵ��\n");
		for(row = 0;row < LEN;row ++){
			for(col = 0;col < LEN;col ++){
				scanf("%d",&(SD->grid[row][col]));
			}
		}
		return ( SD );
	}
	else{
		return ( NULL );
	}
}

void changeAddress(SDL SD){
	if(SD != NULL){
		int row,col;
		SDL newSD;
		findBechanged(SD,&row,&col);
		if(row < LEN&&col < LEN){
			switch( row ){
				case 0:	switch( col ){
							case 0:	newSD = getNewSudoku(SD,0,0,1,0);
									enqueue(newSD);
									newSD = getNewSudoku(SD,0,0,0,1);
									enqueue(newSD);
									changeAddress(Queue[++front]);
									break;
							case 1:	newSD = getNewSudoku(SD,0,1,0,0);
									enqueue(newSD);
									newSD = getNewSudoku(SD,0,1,0,2);
									enqueue(newSD);
									newSD = getNewSudoku(SD,0,1,1,1);
									enqueue(newSD);
									changeAddress(Queue[++front]);
									break;
							case 2:	newSD = getNewSudoku(SD,0,2,0,1);
									enqueue(newSD);
									newSD = getNewSudoku(SD,0,2,1,2);
									enqueue(newSD);
									changeAddress(Queue[++front]);
						}
						break;
				case 1:	switch( col ){
							case 0:	newSD = getNewSudoku(SD,1,0,0,0);
									enqueue(newSD);
									newSD = getNewSudoku(SD,1,0,2,0);
									enqueue(newSD);
									newSD = getNewSudoku(SD,1,0,1,1);
									enqueue(newSD);
									changeAddress(Queue[++front]);
									break;
							case 1:	newSD = getNewSudoku(SD,1,1,0,1);
									enqueue(newSD);
									newSD = getNewSudoku(SD,1,1,2,1);
									enqueue(newSD);
									newSD = getNewSudoku(SD,1,1,1,0);
									enqueue(newSD);
									newSD = getNewSudoku(SD,1,1,1,2);
									enqueue(newSD);
									changeAddress(Queue[++front]);
									break;
							case 2:	newSD = getNewSudoku(SD,1,2,0,2);
									enqueue(newSD);
									newSD = getNewSudoku(SD,1,2,2,2);
									enqueue(newSD);
									newSD = getNewSudoku(SD,1,2,1,1);
									enqueue(newSD);
									changeAddress(Queue[++front]);
							}
						break;
				case 2:	switch( col ){
							case 0:	newSD = getNewSudoku(SD,2,0,1,0);
									enqueue(newSD);
									newSD = getNewSudoku(SD,2,0,2,1);
									enqueue(newSD);
									changeAddress(Queue[++front]);
									break;
							case 1:	newSD = getNewSudoku(SD,2,1,1,1);
									enqueue(newSD);
									newSD = getNewSudoku(SD,2,1,2,0);
									enqueue(newSD);
									newSD = getNewSudoku(SD,2,1,2,2);
									enqueue(newSD);
									changeAddress(Queue[++front]);
									break;
							case 2:	newSD = getNewSudoku(SD,2,2,1,2);
									enqueue(newSD);
									newSD = getNewSudoku(SD,2,2,2,1);
									enqueue(newSD);
									changeAddress(Queue[++front]);
					}
			}	
		}
	}
}

void enqueue(SDL SD){
	if(SD != NULL){
		int judge,num;
		for(num = 0;num <= rear;num ++){
			judge = catchData(Queue[num],SD);
			if(judge == 0){
				return;
			}
		}
		Queue[++rear] = SD;
		outputSudoku(SD);
	}
}

int catchData(SDL SD,SDL match){
	if(SD == NULL||match == NULL){
		printf("\n\n���ľŹ����ǿյģ��޷��жϣ�");
		return;
	}
	int row,col;
	for(row = 0;row < LEN;row++){
		for(col = 0;col < LEN;col++){
			if(SD->grid[row][col] != match->grid[row][col]){
				return ( -1 );
			}
		}
	}
	return ( 0 );
}

//void enqueue(SDL SD){
//	int judge;
//	for(judge = 0;judge <= rear;judge ++){
//		
//	} 
//	if(SD != NULL){
//		Queue[++rear] = SD;
//		outputSudoku(SD);
//	}
//}

SDL getNewSudoku(SDL SD,int row0,int col0,int row,int col){
	if(SD != NULL){
		SDL newSD = copySdoku(SD);
		int changeData;
		changeData = newSD->grid[row0][col0];
		newSD->grid[row0][col0] = newSD->grid[row][col];
		newSD->grid[row][col] = changeData;
		return ( newSD );
	}
	else{
		return ( NULL );
	}
}

SDL copySdoku(SDL becopied){
	if(becopied != NULL){
		SDL newSD = (SDL)malloc(sizeof(SDN));
		int row,col;
		for(row = 0;row < LEN;row ++){
			for(col = 0;col < LEN;col ++){
				newSD->grid[row][col] = becopied->grid[row][col];
			}
		}
		return ( newSD );
	}
	else{
		return ( NULL );
	}
}

void findBechanged(SDL SD,int* row,int* col){
	int Row,Col;
	for(Row = 0;Row < LEN;Row ++){
		for(Col = 0;Col < LEN;Col ++){
			if(SD->grid[Row][Col] == 0){
				goto judge;
			}
		} 
	}
	judge:
	if(Row < LEN&&Col < LEN){
		*row = Row;
		*col = Col;
	}
	else{
		*row = LEN;
		*col = LEN;
	}
}

void outputSudoku(SDL SD){
	if(SD == NULL){
		printf("\n���ľŹ����ǿյģ��޷������");
		return;
	}
	int row,col;
	printf("\n�� %d ������\n",rear);
	for(row = 0;row < LEN;row++){
		for(col = 0;col < LEN;col++){
			printf("%d\t",SD->grid[row][col]);
		}
		printf("\n");
	}
}
