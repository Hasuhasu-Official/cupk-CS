#include <iostream>
#include <vector>
using namespace std;

// ���㴫�ݱհ��ĺ���
void computeTransitiveClosure(vector<vector<int>>& adjMatrix, int vertices) {
    for (int intermediate = 0; intermediate < vertices; intermediate++) {
        for (int startVertex = 0; startVertex < vertices; startVertex++) {
            for (int endVertex = 0; endVertex < vertices; endVertex++) {
                if (adjMatrix[startVertex][intermediate] && adjMatrix[intermediate][endVertex]) {
                    adjMatrix[startVertex][endVertex] = 1;
                }
            }
        }
    }
}

int main() {
    int numVertices;
    cin >> numVertices;
    vector<vector<int>> adjacencyMatrix(numVertices, vector<int>(numVertices));
    for (int i = 0; i < numVertices; i++) {
        for (int j = 0; j < numVertices; j++) {
            cin >> adjacencyMatrix[i][j];
        }
    }
    computeTransitiveClosure(adjacencyMatrix, numVertices);
    for (int i = 0; i < numVertices; i++) {
        for (int j = 0; j < numVertices; j++) {
            cout << adjacencyMatrix[i][j] << " ";
        }
        cout << endl;
    }
    return 0;
}
