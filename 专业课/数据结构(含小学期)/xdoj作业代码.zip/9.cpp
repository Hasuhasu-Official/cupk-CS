#include <iostream>
#include <set>
#include <string>
using namespace std;

// �������ű�ʾ���ַ���ת��Ϊ�ַ������ϵĺ���
set<string> parseStringToSet(const string& str) {
    set<string> stringSet;
    string currentElement;
    for (char ch : str) {
        if (ch == '{' || ch == '}') {
            continue;
        }
        else if (ch == ',') {
            if (!currentElement.empty()) {
                stringSet.insert(currentElement);
                currentElement.clear();
            }
        }
        else {
            currentElement += ch;
        }
    }
    if (!currentElement.empty()) {
        stringSet.insert(currentElement);
    }
    return stringSet;
}

int main() {
    string setRepresentationA, setRepresentationB;
    getline(cin, setRepresentationA);
    getline(cin, setRepresentationB);
    set<string> stringSetA = parseStringToSet(setRepresentationA);
    set<string> stringSetB = parseStringToSet(setRepresentationB);
    bool isSubset = true;
    for (const auto& elem : stringSetA) {
        if (stringSetB.find(elem) == stringSetB.end()) {
            isSubset = false;
            break;
        }
    }
    if (isSubset) {
        cout << "Yes" << endl;
    }
    else {
        cout << "No" << endl;
    }
    return 0;
}
