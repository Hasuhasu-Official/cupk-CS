#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Node {
    char val;
    Node *leftChild;
    Node *rightChild;
    Node(char x) : val(x), leftChild(nullptr), rightChild(nullptr) {}
};

// �����в���ڵ�ĺ���
void addNode(Node *root, const string &path) {
    Node *current = root;
    for (char step : path) {
        if (step == '0') {
            if (!current->leftChild) {
                current->leftChild = new Node('0');
            }
            current = current->leftChild;
        } else if (step == '1') {
            if (!current->rightChild) {
                current->rightChild = new Node('1');
            }
            current = current->rightChild;
        }
    }
}

// ����������ĺ���
void inOrderTraversal(Node *node) {
    if (node == nullptr) {
        return;
    }
    cout << '[';
    inOrderTraversal(node->leftChild);
    cout << node->val << " ";
    inOrderTraversal(node->rightChild);
    cout << ']';
}

int main() {
    int numEntries;
    cin >> numEntries;
    vector<string> paths(numEntries);
    for (int i = 0; i < numEntries; i++) {
        cin >> paths[i];
    }
    Node *treeRoot = new Node('r');
    for (const string &path : paths) {
        addNode(treeRoot, path);
    }
    inOrderTraversal(treeRoot);
    return 0;
}
