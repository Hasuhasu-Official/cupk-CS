#include <iostream>
#include <set>
#include <string>
using namespace std;

// ���ַ���ת��Ϊ�ַ����ϵĺ���
set<char> extractChars(const string& inputStr) {
    set<char> charCollection;
    for (char ch : inputStr) {
        if (ch != '{' && ch != '}' && ch != ',') {
            charCollection.insert(ch);
        }
    }
    return charCollection;
}

int main() {
    string strA, strB;
    getline(cin, strA);
    getline(cin, strB);
    set<char> charSetA = extractChars(strA);
    set<char> charSetB = extractChars(strB);
    cout << "{";
    bool isFirstPair = true;
    for (const auto& charA : charSetA) {
        for (const auto& charB : charSetB) {
            if (!isFirstPair) {
                cout << ",";
            }
            cout << "<" << charA << "," << charB << ">";
            isFirstPair = false;
        }
    }
    cout << "}" << endl;
    return 0;
}
