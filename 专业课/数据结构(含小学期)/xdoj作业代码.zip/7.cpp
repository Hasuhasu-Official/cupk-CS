#include <iostream>
#include <set>
#include <string>
#include <algorithm>
using namespace std;

// ���ַ���ת��Ϊ�ַ����ϵĺ���
set<char> convertStringToCharSet(const string& inputStr) {
    set<char> charSet;
    for (char ch : inputStr) {
        if (ch != '{' && ch != '}' && ch != ',') {
            charSet.insert(ch);
        }
    }
    return charSet;
}

// ��ӡ�ַ����ϵĺ���
void displayCharSet(const set<char>& charCollection) {
    cout << "{";
    for (auto iter = charCollection.begin(); iter != charCollection.end(); ++iter) {
        if (iter != charCollection.begin()) cout << ",";
        cout << *iter;
    }
    cout << "}" << endl;
}

int main() {
    string strA, strB;
    cin >> strA >> strB;
    set<char> charSetA = convertStringToCharSet(strA);
    set<char> charSetB = convertStringToCharSet(strB);
    set<char> combinedSet;
    set_union(charSetA.begin(), charSetA.end(), charSetB.begin(), charSetB.end(), inserter(combinedSet, combinedSet.begin()));
    displayCharSet(combinedSet);
    
    set<char> commonSet;
    set_intersection(charSetA.begin(), charSetA.end(), charSetB.begin(), charSetB.end(), inserter(commonSet, commonSet.begin()));
    displayCharSet(commonSet);
    
    set<char> subtractedSet;
    set_difference(charSetA.begin(), charSetA.end(), charSetB.begin(), charSetB.end(), inserter(subtractedSet, subtractedSet.begin()));
    displayCharSet(subtractedSet);
    
    set<char> symmetricDiffSet;
    set_symmetric_difference(charSetA.begin(), charSetA.end(), charSetB.begin(), charSetB.end(), inserter(symmetricDiffSet, symmetricDiffSet.begin()));
    displayCharSet(symmetricDiffSet);
    
    return 0;
}
